package dev.recreation.lunar.motionblur;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.nio.IntBuffer;

@Mod(modid = "motionblur_recreated", name = "Motion Blur", version = "1.0.0",
     acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class MotionBlurMod {
    // Lunar profile stores "2". The profile does not expose Lunar's proprietary
    // alpha mapping, so this value is retained separately from the visual blend.
    private static final String PROFILE_VALUE = "2";
    private static final float BLEND_ALPHA = 0.18F;

    private int historyTexture = 0;
    private int textureWidth = -1;
    private int textureHeight = -1;
    private boolean hasHistory = false;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null ||
            mc.gameSettings.hideGUI && mc.currentScreen != null) {
            hasHistory = false;
            return;
        }

        int width = mc.displayWidth;
        int height = mc.displayHeight;
        if (width <= 0 || height <= 0) {
            return;
        }

        ensureTexture(width, height);
        if (historyTexture == 0) {
            return;
        }

        if (hasHistory) {
            drawHistory(width, height);
        }

        // Store the current world image after blending, creating a subtle
        // frame-feedback trail. Capture occurs before the HUD render pass.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, historyTexture);
        GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, 0, 0, width, height);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
        hasHistory = true;
    }

    private void ensureTexture(int width, int height) {
        if (historyTexture == 0) {
            historyTexture = GL11.glGenTextures();
        }
        if (textureWidth == width && textureHeight == height) {
            return;
        }

        textureWidth = width;
        textureHeight = height;
        hasHistory = false;

        GL11.glBindTexture(GL11.GL_TEXTURE_2D, historyTexture);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_CLAMP);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_CLAMP);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, width, height, 0,
                GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (IntBuffer) null);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
    }

    private void drawHistory(int width, int height) {
        boolean blendWasEnabled = GL11.glIsEnabled(GL11.GL_BLEND);
        boolean depthWasEnabled = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        boolean textureWasEnabled = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);
        boolean alphaWasEnabled = GL11.glIsEnabled(GL11.GL_ALPHA_TEST);

        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, BLEND_ALPHA);

        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0D, width, height, 0.0D, -1.0D, 1.0D);

        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();

        GL11.glBindTexture(GL11.GL_TEXTURE_2D, historyTexture);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glTexCoord2f(0.0F, 1.0F); GL11.glVertex2f(0.0F, 0.0F);
        GL11.glTexCoord2f(1.0F, 1.0F); GL11.glVertex2f(width, 0.0F);
        GL11.glTexCoord2f(1.0F, 0.0F); GL11.glVertex2f(width, height);
        GL11.glTexCoord2f(0.0F, 0.0F); GL11.glVertex2f(0.0F, height);
        GL11.glEnd();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);

        GL11.glPopMatrix();
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glPopMatrix();
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

        if (!blendWasEnabled) GL11.glDisable(GL11.GL_BLEND);
        if (depthWasEnabled) GL11.glEnable(GL11.GL_DEPTH_TEST);
        if (!textureWasEnabled) GL11.glDisable(GL11.GL_TEXTURE_2D);
        if (alphaWasEnabled) GL11.glEnable(GL11.GL_ALPHA_TEST);
    }
}
