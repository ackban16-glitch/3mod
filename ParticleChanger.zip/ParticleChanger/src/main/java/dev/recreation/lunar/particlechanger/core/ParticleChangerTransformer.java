package dev.recreation.lunar.particlechanger.core;

import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.MethodNode;

public class ParticleChangerTransformer implements IClassTransformer {
    private static final String TARGET = "net.minecraft.client.entity.EntityPlayerSP";
    private static final String PARTICLE_ENUM = "net/minecraft/util/EnumParticleTypes";

    @Override
    public byte[] transform(String name, String transformedName, byte[] basicClass) {
        if (basicClass == null || !TARGET.equals(transformedName)) {
            return basicClass;
        }

        try {
            ClassNode classNode = new ClassNode();
            new ClassReader(basicClass).accept(classNode, 0);

            boolean changed = false;
            for (MethodNode method : classNode.methods) {
                boolean criticalMethod =
                        ("onCriticalHit".equals(method.name) || "func_71009_b".equals(method.name))
                        && "(Lnet/minecraft/entity/Entity;)V".equals(method.desc);

                if (!criticalMethod) {
                    continue;
                }

                for (AbstractInsnNode instruction = method.instructions.getFirst();
                     instruction != null; instruction = instruction.getNext()) {
                    if (instruction.getOpcode() == Opcodes.GETSTATIC &&
                        instruction instanceof FieldInsnNode) {
                        FieldInsnNode field = (FieldInsnNode) instruction;
                        if (PARTICLE_ENUM.equals(field.owner) && "CRIT".equals(field.name)) {
                            field.name = "CRIT_MAGIC";
                            changed = true;
                        }
                    }
                }
            }

            if (!changed) {
                System.err.println("[ParticleChanger] Warning: did not find the expected CRIT field in EntityPlayerSP.");
                return basicClass;
            }

            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            classNode.accept(writer);
            System.out.println("[ParticleChanger] Replaced critical-hit particles with enchanted critical particles.");
            return writer.toByteArray();
        } catch (Throwable error) {
            System.err.println("[ParticleChanger] Transformer failed; keeping original class.");
            error.printStackTrace();
            return basicClass;
        }
    }
}
