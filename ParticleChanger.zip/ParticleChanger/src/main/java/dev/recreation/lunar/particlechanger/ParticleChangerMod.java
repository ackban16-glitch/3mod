package dev.recreation.lunar.particlechanger;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = "particlechanger_recreated", name = "Particle Changer", version = "1.0.0",
     acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class ParticleChangerMod {
    // Exact profile option: alwaysEnchantStrikes = true.
    public static final boolean ALWAYS_ENCHANT_STRIKES = true;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Particle replacement is performed by the coremod transformer.
    }
}
