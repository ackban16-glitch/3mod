package dev.recreation.lunar.staticfov;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod(modid = "staticfov_recreated", name = "Static FOV", version = "1.0.0",
     acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class StaticFovMod {
    // Exact values from the supplied Lunar profile.
    private static final boolean STATIC_FOV = true;
    private static final float DEFAULT_FOV = 91.0F;
    private static final float SPEED_FOV = 90.0F;
    private static final float SPRINTING_FOV = 90.0F;
    private static final float FLYING_FOV = 90.0F;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onFovModifier(EntityViewRenderEvent.FOVModifier event) {
        if (!STATIC_FOV || !(event.entity instanceof EntityPlayer)) {
            return;
        }

        EntityPlayer player = (EntityPlayer) event.entity;
        float targetFov = DEFAULT_FOV;

        if (player.capabilities != null && player.capabilities.isFlying) {
            targetFov = FLYING_FOV;
        } else if (player.isSprinting()) {
            targetFov = SPRINTING_FOV;
        } else if (player.isPotionActive(Potion.moveSpeed)) {
            targetFov = SPEED_FOV;
        }

        event.setFOV(targetFov);
    }
}
